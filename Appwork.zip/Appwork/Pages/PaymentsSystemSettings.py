import time

from Appwork.Locators.locators import Locators
from Appwork.Utils.Utils import Core

class PaymentsSystemSettings():
    def __init__(self, driver):
        self.driver = driver

        Core.driver_refresh(self.driver)
        time.sleep(2)

    def payments_tab(self):
        Core.find_element_byxpath(self.driver, Locators.payment_tab).click()    #payment tab
        Core.find_element_byxpath(self.driver, Locators.export_payment).click()    #export payment switch button
        Core.find_element_byxpath(self.driver, Locators.save_payment).click()
        Core.set_alert(self.driver)
        Core.driver_refresh(self.driver)
        Core.find_element_byxpath(self.driver, Locators.payment_tab).click()  # payment tab
        Core.find_element_byxpath(self.driver, Locators.reset_payment).click()
        Core.set_alert(self.driver)
        Core.driver_refresh(self.driver)
        Core.find_element_byxpath(self.driver, Locators.payment_tab).click()  # payment tab



