import time

from Appwork.Locators.locators import Locators
from Appwork.Utils.Utils import Core
from Appwork.Utils.Utils import Core
from Appwork.Pages import Login
from selenium import webdriver
from selenium.common.exceptions import WebDriverException

class CoreSystemSettings():

    def __init__(self, driver):
        self.driver = driver

    def navigate(self):
        time.sleep(2)
        Core.find_element_byxpath(self.driver, Locators.sidebar_popup).click()  # sidebar popup
        Core.find_element_byxpath(self.driver, Locators.settings_button).click()
        time.sleep(3)
        Core.find_element_byxpath(self.driver, Locators.application_settings).click() # application settings
        # setting logo url
        time.sleep(3)
        Core.find_element_byxpath(self.driver, Locators.setting_logo_url).click()
    def theme_settings(self):
        logo_element = Core.find_element_byxpath(self.driver, Locators.logo_url)
        Core.set_element (logo_element,  'https://www.google.com/', self.driver)  # Application Logo URL
        primary_element = Core.find_element_byxpath(self.driver, Locators.primary_color)
        Core.set_element(primary_element,'#DB0B0B', self.driver)  # Primary Color
        Core.set_element(Core.find_element_byxpath(self.driver, Locators.secondary_color),'#E6780C', self.driver)  # Secondary Color
        Core.set_element(Core.find_element_byxpath(self.driver, Locators.sidebar_color),'#0F13D8', self.driver)  # Sidebar Color
        Core.set_element(Core.find_element_byxpath(self.driver, Locators.sidebar_text),'#AE1F89', self.driver)  # Sidebar Text Color
        Core.find_element_byxpath(self.driver, Locators.save_button).click()  # To Save theme Setting page)
        time.sleep(2)
        Core.set_alert(self.driver)
    def reset_theme(self):
        Core.find_element_byxpath(self.driver,Locators.rest_logo_url).click()  # Logo Url reset button
        Core.set_alert(self.driver)
        Core.find_element_byxpath(self.driver, Locators.reset_primary).click()  # Reset Primary Color
        Core.set_alert(self.driver)
        Core.find_element_byxpath(self.driver, Locators.reset_secondary).click()  # Reset Secondary Color
        Core.set_alert(self.driver)
        Core.find_element_byxpath(self.driver, Locators.reset_sidebar_color).click()  # Reset Sidebar Color
        Core.set_alert(self.driver)
        Core.find_element_byxpath(self.driver, Locators.reset_sidebar_text).click()  # Reset Sidebar Text Color
        Core.set_alert(self.driver)




