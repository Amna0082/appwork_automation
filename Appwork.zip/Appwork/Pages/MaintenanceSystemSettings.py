import time

from Appwork.Locators.locators import Locators
from Appwork.Utils.Utils import Core

class MaintenanceSystemSettings():
    def __init__(self, driver):
        self.driver = driver

        Core.driver_refresh(self.driver)
        time.sleep(2)

    def maintenance_tab(self):
        Core.find_element_byxpath(self.driver, Locators.maintenance_tab).click()    # Maintenance Tab
        Core.find_element_byxpath(self.driver, Locators.workorder_block).click()  # Click on work order block
        Core.find_element_byxpath(self.driver, Locators.export_switch_button).click()   # Export work orders to integrated system "Switch button turn off"
        time.sleep(2)
        Core.find_element_byxpath(self.driver, Locators.save_export).click()    # Export Work Orders save button
        Core.set_alert(self.driver)
        Core.driver_refresh(self.driver)
        Core.find_element_byxpath(self.driver, Locators.maintenance_tab).click()      # Maintenance Tab under property settings
        Core.find_element_byxpath(self.driver, Locators.export_reset_default).click()
        Core.set_alert(self.driver)
        Core.driver_refresh(self.driver)  # to refresh current page
        Core.find_element_byxpath(self.driver, Locators.maintenance_tab).click()     # Maintenance Tab under property settings
        Core.find_element_byxpath(self.driver, Locators.techs_block).click()     # Click on techs
        Core.find_element_byxpath(self.driver, Locators.maps_switch).click()  # Tech Maps Switch button turn off
        # Core.find_element_byxpath(self.driver, Locators.maps_switch_button).click()
        Core.find_element_byxpath(self.driver, Locators.tech_save).click()  # Save Tech Block
        Core.set_alert(self.driver)
        Core.find_element_byxpath(self.driver, Locators.maintenance_tab).click()    # Maintenance Tab under property settings
        Core.find_element_byxpath(self.driver, Locators.techs_block).click()  # Click on techs
        time.sleep(2)
        Core.find_element_byxpath(self.driver, Locators.reset_tech_maps).click()    # Export work orders to integrated system "Reset default"
        Core.set_alert(self.driver)





