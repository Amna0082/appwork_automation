from Appwork.Locators.locators import Locators
from Appwork.Utils.Utils import Core

class Login():
    def __init__(self, driver):
        self.driver = driver

    def invalid_login(self):
        Core.set_element(Core.find_element_byid(self.driver, Locators.email_input), '1talha@invozone.com')
        Core.set_element(Core.find_element_byid(self.driver, Locators.password_input), '1p@ssw0rd#!')
        Core.find_element_byxpath(self.driver, Locators.login_button).click()
        error_message = "Invalid Login"
        errors = self.driver.find_element(self.driver, Locators.error_message)
        
    def success_login(self):
        Core.set_element(Core.find_element_byid(self.driver,  Locators.email_input), 'talha@invozone.com')  # email field
        Core.set_element(Core.find_element_byid(self.driver, Locators.password_input), 'p@ssw0rd#!')  # password field
        Core.find_element_byxpath(self.driver, Locators.login_button).click()   # click on login button

    def logout(self):
        Core.find_element_byxpath(Core.driver, Locators.sidebar_app).click()
        Core.find_element_byxpath(Core.driver, Locators.logout).click()






